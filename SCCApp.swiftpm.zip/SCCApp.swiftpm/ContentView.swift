import SwiftUI



// No need to import VideoDataModel, VideoDataStore, or CollectionViewCell
struct ContentView: View {
    
    @StateObject private var videoState = VideoState()
    @EnvironmentObject var scoreManager: ScoreManager // ✅ Access global score

    //@AppStorage("userProgress")private var userProgress: Int = 1
    
    var allVideosWatched: Bool {
        return videoState.viewedVideos.count >= 10 // Assuming there are 10
    }
    
    @State private var isQuizActive = false
    @State private var progress: CGFloat = 0.75
    
    var currentProgress: Int {
        if scoreManager.score > 3 {
            return 2 // ✅ If quiz score is more than 2, return 2
        } else if allVideosWatched {
            return 1 // ✅ If all videos are watched, return 1
        } else {
            return 0 // ✅ Default progress
        }
    }
    var body: some View {
        NavigationStack {
            
            VStack(spacing: 30) {
                // App Title
                HStack {
                    Text("SignEngage")
                        .font(.largeTitle)
                        .bold()
                    Text("👋") // Emoji for a friendly touch
                        .font(.largeTitle)
                }
                //.offset(y: -50)
                
                
                // ISL Numbers Card with Progress Ring
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.blue)
                    .frame(height: 100)
                    .overlay(
                        HStack {
                            Text("ISL Numbers")
                                .font(.title2)
                                .bold()
                                .foregroundColor(.white)
                            
                            Spacer()
                            
                            CircularProgressView(progress: CGFloat(currentProgress) / 2, current: currentProgress, total: 2) // ✅
                                .frame(width: 100, height: 60)
                        }
                            .padding(.horizontal, 20)
                    )
                    .padding(.horizontal,0)
                    .padding(.top,50)
                    .offset(y:-40)
                
                // Rounded Buttons for Learning & Quiz
                // Rounded Buttons for Learning & Quiz
                VStack(spacing: 50) {
                    NavigationLink(destination: NumbersList().environmentObject(videoState)) {
                        CircularButton(icon: "numbers",color: .blue)
                    
                    }
                    Button(action: {
                        if allVideosWatched {
                            isQuizActive = true
                        }
                    }) {
                        CircularButton(icon: allVideosWatched ? "trophy.fill" : "lock.fill",
                                       color: allVideosWatched ? .yellow : .gray)

                    }
                    .disabled(!allVideosWatched) // Ensures button does nothing if disabled
                }
                .navigationDestination(isPresented: $isQuizActive) {
                    NumbersQuizView()
                }
                .padding(.top, 20)
                
                // Motivational Quote (Fills Space)
                Text("Every hand tells a story 🫶")
                    .font(.headline)
                    .foregroundColor(.gray)
                    .padding(.top, 30)
                
                Spacer()
            }
            .padding()
        }
        //.navigationViewStyle(StackNavigationViewStyle())
        .navigationDestination(isPresented: $isQuizActive) { // ✅ Works inside NavigationStack
            NumbersQuizView()        // Ensures single-screen navigation
        }
    }
}
    
        
        // MARK: - Circular Progress View
        struct CircularButton: View {
            var icon: String
            var color: Color
            var disabled: Bool = true
            
            var body: some View {
                Circle()
                    .fill(color)
                    .frame(width: 120, height: 120)
                    .overlay(
                        Image(systemName: icon)
                            .font(.largeTitle)
                            .foregroundColor(.white)
                    )
                    .shadow(radius: 5) // Adds depth
            }
        }
        
        // MARK: - Custom Circular Progress View
        struct CircularProgressView: View {
            var progress: CGFloat // 0.0 to 1.0
            var current : Int
            var total : Int
            
            var body: some View {
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.5), lineWidth: 10)
                    Circle()
                        .trim(from: 0, to: progress)
                        .stroke(Color.yellow, style : StrokeStyle(lineWidth: 10,lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        
                    // Rotate for correct start             // Display progress as a fraction
                    Text("\(current)/\(total)")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                }
               // .background(Circle().fill(Color.white)) // Makes background solid
            }
        }
        
    struct ContentView_Previews: PreviewProvider {
            static var previews: some View {
                ContentView()
                    .environmentObject(ScoreManager())
                    .environmentObject(VideoState())
            }
        }
  
    

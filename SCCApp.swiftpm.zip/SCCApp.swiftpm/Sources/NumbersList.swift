import SwiftUI
import Foundation

    struct NumbersList: View {
        @EnvironmentObject var videoState: VideoState
        let numbers = Array(1...10)

        var body: some View {
            ScrollView {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 2), spacing: 10) {
                  ForEach(numbers, id: \.self) { number in
                        let isViewed = videoState.viewedVideos[number] ?? false

                      NavigationLink(destination: NumbersVideoPlayer(videoNumber: number).environmentObject(videoState)
                      ){
                          NumbersListCell(number: number, isViewed: isViewed)
                      }
                    }
                }
                .padding()
            }
            .navigationTitle("Choose a Number")
            .navigationBarTitleDisplayMode(.large)
        }
    }


// ✅ Ensure VideoState updates trigger a view refresh
class VideoState: ObservableObject {
    @Published var viewedVideos: [Int: Bool] = [:]
}


struct NumbersList_Previews: PreviewProvider {
    static var previews: some View {
        NumbersList().environmentObject(VideoState())
    }
}

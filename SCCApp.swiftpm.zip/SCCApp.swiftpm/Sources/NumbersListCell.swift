import SwiftUI

struct NumbersListCell: View {
    let number: Int
    let isViewed: Bool // ✅ Track if video was viewed
    
    public init(number: Int, isViewed: Bool) { // ✅ Updated init
        self.number = number
        self.isViewed = isViewed
    }
    
    public var body: some View {
        Text("\(number)")
            .font(.system(size: 40, weight:.semibold, design: .rounded))
            
            //.bold()
            .frame(maxWidth: .infinity,minHeight : 130,alignment: .leading)
            .padding(.leading, 20)// ✅ Makes cells large
            .background(isViewed ? Color.green : Color.blue) // ✅ Change color if viewed
            .foregroundColor(.white)
            .cornerRadius(15)
            .shadow(radius: 5)
            .overlay(
                Image(systemName: isViewed ? "video.fill.badge.checkmark" : "video.fill") // ✅ Change symbol based on isViewed
                    .font(.title2) // Adjust size
                    .foregroundColor(.white) // Make it visible
                    .padding(10), // Add spacing from edges
                alignment: .topTrailing // ✅ Position in top-right corner
            )
    }
}


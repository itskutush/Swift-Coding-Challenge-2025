import SwiftUI
import AVKit

// Data Model for Quiz Questions
struct NumbersQuizDataModel {
    let videoName: String
    let options: [String]
    let correctAnswerIndex: Int
}

// Sample Quiz Questions
let NumbersquizQuestions = [
    NumbersQuizDataModel(videoName: "1", options: ["One", "Two", "Three", "Four"], correctAnswerIndex: 0),
    NumbersQuizDataModel(videoName: "7", options: ["Six", "Seven", "Two", "Eight"], correctAnswerIndex: 1),
    NumbersQuizDataModel(videoName: "3", options: ["Six", "Seven", "Three", "Eight"], correctAnswerIndex: 2),
    NumbersQuizDataModel(videoName: "5", options: ["Six", "Seven", "Two", "Five"], correctAnswerIndex: 3),
    NumbersQuizDataModel(videoName: "2", options: ["Six", "Seven", "Two", "Five"], correctAnswerIndex: 2)
]

// SwiftUI View for Numbers Quiz
struct NumbersQuizView: View {
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswer: Int? = nil
    @State private var correctAnswersCount = 0
    @State private var showCompletionScreen = false
    @State private var player: AVPlayer? = nil
    @State private var navigateToContent = false // ✅ Used
    @EnvironmentObject var scoreManager: ScoreManager // ✅ Access global score

    
    var body: some View {
        NavigationStack {
            if navigateToContent {
                ContentView() // ✅ Proper navigation to ContentView
            }else  if showCompletionScreen {
                QuizCompletionView(
                    score: correctAnswersCount,
                    total: NumbersquizQuestions.count,
                    restartQuiz: restartQuiz
                    
                )

                .navigationBarBackButtonHidden(true) // Hide back button
            } else {
                let question = NumbersquizQuestions[currentQuestionIndex]
                let videoURL = Bundle.main.url(forResource: question.videoName, withExtension: "mov")!
                
                VStack {
                    // Progress Bar
                    HStack {
                        ProgressView(value: Double(currentQuestionIndex + 1), total: Double(NumbersquizQuestions.count))
                            .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                            .frame(width: 325)
                        
                        Text("\(currentQuestionIndex + 1) / \(NumbersquizQuestions.count)")
                            .font(.headline)
                            .foregroundColor(.blue)
                    }
                    .padding(.bottom,20)
                    
                    // Video Player
                    VideoPlayer(player: player)
                        .frame(width: 380, height: 300)
                        .cornerRadius(10)
                        .padding(.horizontal, 150)
                        //.scaledToFit()
                        .onAppear {
                            player = AVPlayer(url: videoURL)
                            player?.play()
                        
                        }
                    
                    // Question
                    Text("Choose the correct answer")
                        .font(.headline)
                        .foregroundColor(.blue)
                        .padding(.top, 10)
                    
                    // Answer Options
                    ForEach(0..<question.options.count, id: \.self) { index in
                        Button(action: {
                            selectedAnswer = index
                            if index == question.correctAnswerIndex {
                                correctAnswersCount += 1
                            }
                        }) {
                            Text(question.options[index])
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(selectedAnswer == nil ? Color.blue :
                                                (selectedAnswer == index ?
                                                 (index == question.correctAnswerIndex ? Color.green : Color.red) :
                                                    Color.gray.opacity(0.5)))
                                .cornerRadius(10)
                                .padding(.horizontal)
                        }
                        .disabled(selectedAnswer != nil && selectedAnswer != index)
                    }
                    
                    // Next Button
                    Button(action: {
                        if currentQuestionIndex + 1 < NumbersquizQuestions.count {
                            currentQuestionIndex += 1
                            selectedAnswer = nil
                            player = AVPlayer(url: Bundle.main.url(forResource: NumbersquizQuestions[currentQuestionIndex].videoName, withExtension: "mov")!)
                            player?.play()
                        } else {
                            scoreManager.score = correctAnswersCount 
                            showCompletionScreen = true
                        }
                    }) {
                        Text("Next")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding() // ✅ Makes the text tappable
                            .frame(minWidth: 150, minHeight: 50) // ✅ Expands the tappable area
                            .background(Color.blue) // ✅ Adds a visible background
                            .cornerRadius(10)
                    }
                    .disabled(selectedAnswer == nil)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                    .padding(.top, 20)
                }
                .navigationTitle("Numbers Quiz")
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
    
    // Function to Restart the Quiz
    func restartQuiz() {
        currentQuestionIndex = 0
        correctAnswersCount = 0
        selectedAnswer = nil
        showCompletionScreen = false
        player = AVPlayer(url: Bundle.main.url(forResource: NumbersquizQuestions[currentQuestionIndex].videoName, withExtension: "mov")!)
        player?.play()
    }
}
// Quiz Completion Screen

struct QuizCompletionView: View {
    let score: Int
    let total: Int
    let restartQuiz: () -> Void
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var scoreManager: ScoreManager // ✅ Use environment object


    var body: some View {
        let resultColor: Color = score <= 2 ? .red : .green // ✅ Choose color based on score
        VStack {
            
            Text("Quiz Completed!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            Text("You scored \(score) out of \(total)")
                .font(.title)
                .foregroundColor(score >= 3 ? .blue : .red)
                .padding()

            if score <= 2 {
                Text("You need to try again!")
                    .font(.title2)
                    .foregroundColor(resultColor)
                    .padding()
            }

            Image(systemName: score >= 3 ? "star.fill" : "xmark.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .foregroundColor(score >= 3 ? .yellow : .red)
                .padding()

            if score <= 2 {
                Button("Retry Quiz") {
                    restartQuiz()
                }
                .frame(width: 200, height: 50)
                .background(Color.red)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
            } else {
                Button("Back to Home") {
                    if score >= 3 && scoreManager.score == 0  { // ✅
                        scoreManager.score = score
                    }
                    presentationMode.wrappedValue.dismiss() // This will pop back to ContentView
                    
                }
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
            }
        }
    }
}
struct NumbersQuizView_Previews: PreviewProvider {
    static var previews: some View {
        NumbersQuizView()
    }
}

//
//  File.swift
//  SCCApp
//
//  Created by user@90 on 22/02/25.
//

import Foundation
import SwiftUI
import AVKit

struct NumbersVideoPlayer: View {
    @EnvironmentObject var videoState: VideoState // ✅ Access global
    @State private var videoIndex: Int
    @State private var player = AVPlayer()
    @State private var currentTime: Double = 0.0
    @State private var score = 0.0
    @State private var isViewed = false
    @State private var isFinished = false

    
    let totalVideos = 10
    // let onVideoViewed: (Int) -> Void
    
    let transcriptionSteps: [Int: [(time: Double, text: String)]] = [
        1: [
            (0.0, "1. Raise your index finger."),
            (2.0, "2. Keep your hand steady."),
            (3.0, "3. This represents the number one in sign language.")
        ],
        2: [
            (0.0, "1. Raise your index and middle fingers."),
            (2.0, "2. Keep your palm facing outward."),
            (3.0, "3.This gesture represents the number two."),
        ],
        3: [
            (0.0, "1. Extend your thumb, index, and middle fingers."),
            (2.0, "2. This forms the number three in sign language."),
            (3.0, "3. Make sure your fingers are clearly visible.")
        ],
        4: [
            (0.0, "1.Raise your index ,middle and ring fingers."),
            (2.0, "2. Keep your palm facing outward."),
            (3.0, "3.This gesture represents the number four."),
            (4.0, "4.Hold for a moment before lowering your hand.")
        ],
        5: [
            (0.0, "1. Raise your index,middle,ring and little fingers."),
            (2.0, "2. Keep your palm facing outward."),
            (3.0, "3. This gesture represents the number five."),
            (4.0, "4. Hold for a moment before lowering your hand.")
        ],
        6: [
            (0.0, "1. Raise your index finger"),
            (1.0, "2. Move your index finger to trace a 6 in the air."),
            (2.0, "3. This gesture represents the number six."),
            (3.0, "4. Hold for a moment before lowering your hand.")
        ],
        7: [
            (0.0, "1. Raise your index finger."),
            (1.0, "2. Curl the tip inwards"),
            (2.0, "3. This gesture represents the number seven."),
            (3.0, "4. Hold for a moment before lowering your hand.")
        ],
        8: [
            (0.0, "1. Raise your thumb , index and middle fingers."),
            (2.0, "2. Keep your palm facing outward."),
            (3.0, "3. This gesture represents the number eight."),
            (4.0, "4. Hold for a moment before lowering your hand.")
        ],
        9: [
            (0.0, "1. Make a fist with your palm facing ourwards"),
            (2.0, "2. Release your thumb."),
            (3.0, "3. This gesture represents the number nine."),
            (4.0, "4. Hold for a moment before lowering your hand.")
        ],
        10: [
            (0.0, "1. Sign 1"),
            (2.0, "2. Bring your fingertips together to form a circle to sign 0"),
            (3.0, "3. This gesture represents the number 10.")
        ]
        
    ]
    /* init(videoNumber: Int, onVideoViewed: @escaping (Int) -> Void) {
     _videoIndex = State(initialValue: videoNumber)
     self.onVideoViewed = onVideoViewed
     }
     */
    init(videoNumber: Int) {
        self.videoIndex = videoNumber
    }
    
    var body: some View {
        VStack {
            if isFinished{
                CongratulatoryView()
            }
            else if videoIndex == totalVideos && (1...totalVideos).allSatisfy({ videoState.viewedVideos[$0] == true }) {
                CongratulatoryView()
            }else{
                Text("Sign \(videoIndex)")
                    .font(.headline.bold())
                    .foregroundColor(.black)
                    .padding(.top, 20)
                    .offset(y: -120)
                
                if let url = Bundle.main.url(forResource: "\(videoIndex)", withExtension: "mov") {
                    ZStack {
                        VideoPlayer(player: player)
                            .frame(width: 380, height: 300)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding(.horizontal,20)
                        
                            .onAppear {
                                player.replaceCurrentItem(with: AVPlayerItem(url: url))
                                player.play()
                                startTimer()
                            }
                            .offset(y: -110)
                        
                        VStack(alignment: .leading) {
                            Text("You can follow these steps:")
                                .font(.subheadline)
                                .foregroundColor(.black)
                                .bold()
                                .padding(.top, 110)
                                .padding(.leading, 30)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .offset(y: 80)
                            
                            VStack(alignment: .leading) {
                                ForEach(currentStepText(), id: \.self) { step in
                                    Text(step)
                                        .font(.subheadline)
                                        .foregroundColor(.black)
                                        .multilineTextAlignment(.leading)
                                        .padding(.top, 2)
                                        .padding(.leading, 30)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .offset(y: 90)
                        }
                        
                    }
                    
                    Button(action: {
                        goToNextVideo()
                    }) {
                        Text(videoIndex == totalVideos ? "Finish" : "Next Video")
                            .font(.title2)
                            .bold()
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 380)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .disabled(videoIndex > totalVideos)
                    .padding(.bottom, 20)
                    .offset(y: 120)
                    
                } else {
                    Text("❌ Video not found: \(videoIndex).mov")
                        .foregroundColor(.red)
                        .bold()
                        .padding()
                }
            }
            /*.onAppear {
             onVideoViewed(videoIndex)
             }
             */
              //.navigationTitle("Numbers Lessons")
        }
        .navigationTitle("Lesson \(videoIndex)")
    }
    
    func playVideo(url: URL) {
        player.replaceCurrentItem(with: AVPlayerItem(url: url))
        player.play()
        startTimer()
    }
    
    func startTimer() {
        player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 600), queue: .main) { time in
            DispatchQueue.main.async {
                currentTime = CMTimeGetSeconds(time)
            }
        }
    }
    
    func currentStepText() -> [String] {
        let steps = transcriptionSteps[videoIndex] ?? []
        return steps.filter { currentTime >= $0.time }.map { $0.text }
    }
    
    /*  func goToNextVideo() {
     if videoIndex < totalVideos {
     videoState.viewedVideos[videoIndex] = true // ✅ Mark current video as viewed
     print("Marked video \(videoIndex) as viewed")
     
     
     
     videoIndex += 1 // ✅ Move to next video
     
     if videoIndex <= totalVideos {
     videoState.viewedVideos[videoIndex] = true // ✅ Mark next video as viewed
     print("Marked video \(videoIndex) as viewed")
     }
     
     currentTime = 0.0
     player.pause()
     
     if let nextUrl = Bundle.main.url(forResource: "\(videoIndex)", withExtension: "mov") {
     playVideo(url: nextUrl)
     }
     }else {
     isFinished = true
     }
     }
     */
    
    func goToNextVideo() {
        // ✅ Mark the current video as viewed
        videoState.viewedVideos[videoIndex] = true
        print("Marked video \(videoIndex) as viewed")
        
        // ✅ Check if all previous videos have been watched
        let allVideosWatched = (1...totalVideos).allSatisfy { videoState.viewedVideos[$0] == true }
        
        if allVideosWatched && videoIndex == totalVideos {
            isFinished = true // ✅ Trigger Congratulations screen
        } else if videoIndex < totalVideos {
            videoIndex += 1 // ✅ Move to the next video
            currentTime = 0.0
            player.pause()
            
            if let nextUrl = Bundle.main.url(forResource: "\(videoIndex)", withExtension: "mov") {
                playVideo(url: nextUrl)
            }
        }
    }
}
  
     

    
    
    //MARK: Congratulations View
    
    struct CongratulatoryView: View {
       // @Binding var quizStarted: Bool
        var body: some View {
            VStack(spacing: 20) {
                Text("🎉 Congratulations! 🎉")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.blue)
                
                Text("You have completed the ISL Numbers lessons!")
                    .font(.title2)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                NavigationLink(destination: NumbersQuizView()) { // ✅ Pass quizPassed binding

                    Text("Take the Quiz")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 200)
                        .background(Color.green)
                        .cornerRadius(10)
                }
            }
            .padding()
            .navigationTitle("")
        }
        
      
    }
    
struct CongratulatoryView_Previews: PreviewProvider {
    static var previews: some View {
        CongratulatoryView()
    }
}



     
 

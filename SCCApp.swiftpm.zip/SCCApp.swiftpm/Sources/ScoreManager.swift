//
//  File.swift
//  SCCApp
//
//  Created by user@90 on 23/02/25.
//

import Foundation
import SwiftUI

class ScoreManager: ObservableObject {
    @Published var score: Int = 0 // Start from 0
}

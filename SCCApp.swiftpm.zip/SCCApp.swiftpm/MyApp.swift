import SwiftUI

@main
struct YourApp: App {
    @StateObject private var videoState = VideoState()
    @StateObject private var scoreManager = ScoreManager()
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
            
            .environmentObject(videoState)
            .environmentObject(scoreManager)// ✅ Inject VideoState
        }
    }
}
